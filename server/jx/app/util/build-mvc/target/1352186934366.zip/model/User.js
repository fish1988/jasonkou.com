J.model('User', {
			fields : ['id','name']
		})