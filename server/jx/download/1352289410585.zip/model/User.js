J.model('User', {
			fields : ['userId','userName']
		})